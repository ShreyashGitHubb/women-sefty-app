import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';

class LocationService {
  static Future<LocationPermission> checkAndRequestPermission() async {
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    return permission;
  }

  static Future<Map<String, dynamic>> getCurrentLocation() async {
    final permission = await checkAndRequestPermission();
    if (permission == LocationPermission.denied) {
      throw Exception('Location permission denied');
    }

    final position = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );

    final placemarks = await placemarkFromCoordinates(
      position.latitude,
      position.longitude,
    );

    return {
      'location': LatLng(position.latitude, position.longitude),
      'address': placemarks.first.street ?? '',
    };
  }

  static Future<String> getAddressFromLatLng(LatLng location) async {
    try {
      final placemarks = await placemarkFromCoordinates(
        location.latitude,
        location.longitude,
      );
      return placemarks.first.street ?? '';
    } catch (e) {
      return "Address not found"; // Handle geocoding errors gracefully
    }
  }
}

class MapPicker extends StatefulWidget {
  final LatLng? initialLocation;

  const MapPicker({super.key, this.initialLocation});

  @override
  State<MapPicker> createState() => _MapPickerState();
}

class _MapPickerState extends State<MapPicker> {
  late GoogleMapController _controller;
  LatLng? _selectedLocation;
  bool _isLoading = true;
  bool _hasError = false;
  Set<Marker> _virarMarkers = {}; // Add markers for Virar

  @override
  void initState() {
    super.initState();
    _initializeMap();
    _addVirarMarkers();
  }

  void _addVirarMarkers() {
    _virarMarkers = {
      Marker(
        markerId: const MarkerId('Jivdani Temple'),
        position: const LatLng(19.4674, 72.8028),
        infoWindow: const InfoWindow(title: 'Jivdani Temple'),
      ),
      Marker(
        markerId: const MarkerId('Arnala Beach'),
        position: const LatLng(19.4124, 72.6987),
        infoWindow: const InfoWindow(title: 'Arnala Beach'),
      ),
      Marker(
        markerId: const MarkerId('Rajodi Beach'),
        position: const LatLng(19.4310, 72.7667),
        infoWindow: const InfoWindow(title: 'Rajodi Beach'),
      ),
      Marker(
        markerId: const MarkerId('Virar Beach'),
        position: const LatLng(19.4444, 72.7842),
        infoWindow: const InfoWindow(title: 'Virar Beach'),
      ),
    };
  }

  Future<void> _initializeMap() async {
    setState(() {
      _isLoading = true;
      _hasError = false;
    });

    if (widget.initialLocation != null) {
      _selectedLocation = widget.initialLocation;
      setState(() {
        _isLoading = false;
      });
      return;
    }

    try {
      final currentLocation = await LocationService.getCurrentLocation();
      setState(() {
        _selectedLocation = currentLocation['location'] as LatLng;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _hasError = true;
        _selectedLocation = const LatLng(0, 0);
      });
      print('Error getting location: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Choose Location',
          style: TextStyle(color: Colors.black),
        ),
        actions: [
          if (_selectedLocation != null)
            TextButton(
              onPressed: () => Navigator.pop(context, _selectedLocation),
              child: const Text(
                'Confirm',
                style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
        ],
      ),
      body:
          _isLoading
              ? const Center(child: CircularProgressIndicator())
              : _hasError
              ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      'Unable to get location. Please check permissions or try again.',
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: _initializeMap,
                      child: const Text('Retry'),
                    ),
                  ],
                ),
              )
              : GoogleMap(
                initialCameraPosition: CameraPosition(
                  target: _selectedLocation!,
                  zoom: 12, // Reduced zoom for better Virar view
                ),
                onMapCreated: (controller) => _controller = controller,
                onTap: (location) {
                  setState(() => _selectedLocation = location);
                },
                markers: _virarMarkers.union(
                  _selectedLocation == null
                      ? {}
                      : {
                        Marker(
                          markerId: const MarkerId('selected'),
                          position: _selectedLocation!,
                        ),
                      },
                ),
              ),
    );
  }
}
