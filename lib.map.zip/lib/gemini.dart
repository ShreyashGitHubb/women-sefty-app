import 'dart:convert';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:map_app/api.dart'; // Assuming you have your API key here
import 'package:flutter_tts/flutter_tts.dart'; // For text-to-speech

class GeminiVoiceAssistant {
  GeminiVoiceAssistant()
      : _model = GenerativeModel(
          model: 'gemini-1.5-flash-latest',
          apiKey: Geminiapi,
        ),
        _tts = FlutterTts();

  final GenerativeModel _model;
  final FlutterTts _tts;

  Future<void> speak(String text) async {
    await _tts.setLanguage("en-US"); // You can change the language
    await _tts.setPitch(1);
    await _tts.speak(text);
  }

  Future<void> handleVoiceCommand(String userCommand) async {
    try {
      final response = await _getVoiceResponse(userCommand);
      if (response != null && response.isNotEmpty) {
        await speak(response);
      } else {
        await speak("I'm sorry, I couldn't understand that.");
      }
    } on GenerativeAIException catch (e) {
      print("Gemini API Error: ${e.toString()}");
      await speak("There was an error processing your request.");
    } catch (e) {
      print("Error: ${e.toString()}");
      await speak("An unexpected error occurred.");
    }
  }

  Future<String?> _getVoiceResponse(String userCommand) async {
    final prompt = '''
You are a helpful voice assistant. Respond to the user's voice command in a natural and conversational way.
User command: $userCommand
Response:
''';

    final response = await _model.generateContent([Content.text(prompt)]);
    return response.text;
  }
}