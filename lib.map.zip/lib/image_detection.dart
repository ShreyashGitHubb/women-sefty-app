import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:image_picker/image_picker.dart';

class ImageDetectionScreen extends StatefulWidget {
  @override
  _ImageDetectionScreenState createState() => _ImageDetectionScreenState();
}

class _ImageDetectionScreenState extends State<ImageDetectionScreen> {
  final picker = ImagePicker();
  File? _image;
  String _analysisResult = '';
  bool _isLoading = false;
  final GenerativeModel _model = GenerativeModel(
    model: 'gemini-1.5-pro-latest',
    apiKey: 'AIzaSyAsKT6BMedNILln1Jb7NerLcGeqESvfW1k', // Replace with your actual API key
  );

  Future<void> _pickImage(ImageSource source) async {
    final pickedFile = await picker.pickImage(source: source);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
        _analysisResult = '';
      });
      _analyzeImage();
    }
  }

  Future<void> _analyzeImage() async {
    if (_image == null) return;
    setState(() => _isLoading = true);

    try {
      final imageBytes = await _image!.readAsBytes();
      final base64Image = base64Encode(imageBytes);

      // Assuming the API accepts Base64-encoded images
      final content = [Content.text(base64Image)];

      final response = await _model.generateContent(content);
      _analysisResult = response.text ?? 'No response from Gemini.';
      
      // Log the response for debugging
      print('API Response: $_analysisResult');
    } on GenerativeAIException catch (e) {
      _analysisResult = 'Gemini API Error: ${e.toString()}';
      print('Gemini API Error: ${e.toString()}');
    } catch (e) {
      _analysisResult = 'Error: ${e.toString()}';
      print('Error: ${e.toString()}');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('AI Image Detector')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _image == null
                      ? Icon(Icons.image, size: 100, color: Colors.grey)
                      : Image.file(_image!, height: 200, fit: BoxFit.cover),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton.icon(
                        onPressed: () => _pickImage(ImageSource.gallery),
                        icon: Icon(Icons.photo),
                        label: Text('Gallery'),
                      ),
                      ElevatedButton.icon(
                        onPressed: () => _pickImage(ImageSource.camera),
                        icon: Icon(Icons.camera_alt),
                        label: Text('Camera'),
                      ),
                    ],
                  ),
                  SizedBox(height: 20),
                  _isLoading
                      ? CircularProgressIndicator()
                      : Expanded(
                          child: SingleChildScrollView(
                            child: Text(
                              _analysisResult,
                              textAlign: TextAlign.center,
                              style: TextStyle(fontSize: 16),
                            ),
                          ),
                        ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}