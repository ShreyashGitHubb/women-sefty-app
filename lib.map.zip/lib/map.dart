import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:latlong2/latlong.dart';

class MapScreen extends StatefulWidget {
  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  List<Marker> _markers = [];
  LatLng _center = LatLng(19.0760, 72.8777); // Mumbai Center

  @override
  void initState() {
    super.initState();
    _loadInitialMarkers();
  }

  Future<void> _loadInitialMarkers() async {
    await _addMarkerFromAddress("Gateway of India, Mumbai", "Gateway of India");
    await _addMarkerFromAddress("Chhatrapati Shivaji Terminus, Mumbai", "CST");
    await _addMarkerFromAddress("Marine Drive, Mumbai", "Marine Drive");
    await _addMarkerFromAddress(
      "Siddhivinayak Temple, Mumbai",
      "Siddhivinayak Temple",
    );
    await _addMarkerFromAddress("Haji Ali Dargah, Mumbai", "Haji Ali Dargah");
    await _addMarkerFromAddress("Juhu Beach, Mumbai", "Juhu Beach");
    await _addMarkerFromAddress("Bandra-Worli Sea Link, Mumbai", "Sea Link");
  }

  Future<void> _addMarkerFromAddress(String address, String title) async {
    try {
      LatLng? position = await geocodeAddress(address);
      if (position != null) {
        _addMarker(position, title);
      } else {
        print("Geocoding failed for $address");
      }
    } catch (e) {
      print("Error adding marker from address: $e");
    }
  }

  Future<LatLng?> geocodeAddress(String address) async {
    final url = Uri.parse(
      'https://nominatim.openstreetmap.org/search?q=$address&format=json',
    );

    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data.isNotEmpty) {
          final lat = double.parse(data[0]['lat']);
          final lon = double.parse(data[0]['lon']);
          return LatLng(lat, lon);
        }
      } else {
        print('Geocoding failed: ${response.statusCode}');
      }
    } catch (e) {
      print('Error during geocoding: $e');
    }
    return null;
  }

  void _addMarker(LatLng position, String title) {
    setState(() {
      _markers.add(
        Marker(
          point: position,
          width: 40,
          height: 40,
          child: Tooltip(
            message: title,
            child: Icon(Icons.location_pin, color: Colors.red, size: 40),
          ),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mumbai Famous Places')),
      body: FlutterMap(
        options: MapOptions(minZoom: 10.0, maxZoom: 12.0),
        children: [
          TileLayer(
            subdomains: [
              'mt0',
              'mt1',
              'mt2',
              'mt3',
            ], //Using google maps instead of osm
          ),
          MarkerLayer(markers: _markers),
        ],
      ),
    );
  }
}
