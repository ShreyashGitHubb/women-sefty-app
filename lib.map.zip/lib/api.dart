final Geminiapi = 'AIzaSyAsKT6BMedNILln1Jb7NerLcGeqESvfW1k';
