import 'package:flutter/material.dart';
import 'package:map_app/gemini.dart';
import 'package:map_app/ronak.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:permission_handler/permission_handler.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(home: MyHomePage());
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final GeminiVoiceAssistant _assistant = GeminiVoiceAssistant();
  final stt.SpeechToText _speech = stt.SpeechToText();
  bool _isListening = false;
  String _recognizedWords = '';

  @override
  void initState() {
    super.initState();
    _initSpeech();
  }

  void _initSpeech() async {
    bool available = await _speech.initialize(
      onError: (error) {
        print('Speech recognition error: $error');
        setState(() {
          _isListening = false;
        });
      },
    );
    if (!available) {
      print('Speech recognition not available');
    }
  }

  Future<void> _startListening() async {
    var status = await Permission.microphone.request();
    if (status.isGranted) {
      if (!_isListening) {
        _recognizedWords = '';
        _speech.listen(
          onResult: (result) {
            setState(() {
              _recognizedWords = result.recognizedWords;
              if (result.finalResult) {
                _processCommand();
              }
            });
          },
        );
        setState(() {
          _isListening = true;
        });
      } else {
        _stopListening();
      }
    } else {
      print('Microphone permission denied');
    }
  }

  void _stopListening() {
    if (_isListening) {
      _speech.stop();
      setState(() {
        _isListening = false;
      });
    }
  }

  void _processCommand() {
    if (_recognizedWords.isNotEmpty) {
      _assistant.handleVoiceCommand(_recognizedWords);
      _recognizedWords = '';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Gemini Voice Assistant')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            ElevatedButton(
              onPressed: _startListening,
              child: Text(_isListening ? 'Stop Listening' : 'Start Listening'),
            ),
            SizedBox(height: 10),
            Text(_isListening ? 'Listening...' : ''),
            if (_recognizedWords.isNotEmpty && !_isListening)
              Text('Recognized: $_recognizedWords'),
          ],
        ),
      ),
    );
  }
}
